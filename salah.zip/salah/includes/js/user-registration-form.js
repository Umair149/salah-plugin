jQuery(document).ready(function($) {
    $('#user-registration-form').submit(function(event) {
        event.preventDefault();
        
        // Disable submit button
        $('#user-registration-form button[type="submit"]').prop('disabled', true);
        
        // Clear error message
        $('#user-registration-message').html('');
        
        // Get form data
        var form_data = $(this).serialize();
        
        // Send AJAX request
        $.ajax({
            type: 'POST',
            dataType: 'json',
            url: user_registration_form.ajax_url,
            data: form_data + '&nonce=' + user_registration_form.nonce,
            success: function(response) {
                // Display success message
                $('#user-registration-message').html('<div class="success">' + response.data + '</div>');
                
                // Clear form fields
                $('#user-registration-form input[type="text"]').val('');
                $('#user-registration-form input[type="email"]').val('');
                $('#user-registration-form input[type="password"]').val('');
            },
            error: function(response) {
                // Display error message
                $('#user-registration-message').html('<div class="error">' + response.responseJSON.data + '</div>');
            },
            complete: function() {
                // Enable submit button
                $('#user-registration-form button[type="submit"]').prop('disabled', false);
            }
        });
    });

    
    $('form#prayer-forme').submit(function(event) {
        event.preventDefault();

        // Disable submit button
        $('#prayer-form button[type="submit"]').prop('disabled', true);
        
        // Clear error message
        $('#prayer-form-message').html('');
    //console.log('gg');
        // Retrieve the form values
        var prayer_time = $('select[name="prayer_time"]').val();
        var time = $('input[name="time"]').val();
        var current_datetime = $('input[name="current_datetime"]').val();
        var user_id = $('input[name="user_id"]').val();
    
        // Send the form data to the server using AJAX
        $.ajax({
        type: 'POST',
        dataType: 'json',
        url: 'prayer_form_object.ajax_url',
        data: { 
            action: 'prayer_form_ajax',
            prayer_time: prayer_time,
            time: time,
            current_datetime: current_datetime,
            user_id: user_id
        },
        success: function(response) {
            // Display a success message
            $('form#prayer-form-message').html('<p>Thank you for submitting the form!</p>');
            $('#prayer-form-message').html('<div class="success">' + response + '</div>');
                
                // Clear form fields
                $('#prayer-form input[type="prayer_time"]').val('');
                $('#prayer-form input[type="time"]').val('');
                $('#prayer-form input[type="current_datetime"]').val('');
                $('#prayer-form input[type="user_id"]').val('');
        },
        error: function(response) {
            // Display an error message
            $('form#prayer-form-message').html('<div class="error">' + response + '</div>');
            console.log(response);
            console.log('<p>There was an error submitting the form.</p>');
        }
        });
    });
      
      
});
